PROGETTO EMOTIONAL SONGS
LABORATORIO B, CORSO DI LAUREA TRIENNALE IN INFORMATICA
UNIVERSITA' DEGLI STUDI DELL'INSUBRIA

PROGETTO REALIZZATO DA:

-Cermisoni Marco, MATRICOLA 748739
 mcermisoni@studenti.uninsubria.it

-Oldani Marco, MATRICOLA 748243
 moldani@studenti.uninsubria.it

-De Vito Francesco, MATRICOLA 749044
 fdevito3@studenti.uninsubria.it

-Auteri Samuele, MATRICOLA 749710
 sauteri@studenti.uninsubria.it

*************************************************************************************************
++ CONTENUTI DELL'ARCHIVIO ++

    --> EmotionalSongs.jar : file jar eseguibile
    --> src : contiene i file sorgenti (.java)
    --> javadoc : documentazione javadoc del progetto
    --> SchemaER : schema ER del database e schema logico
    --> UML : UML del progetto
    --> Manuale Tecnico.pdf : manuale tecnico
    --> Manuale Utente.pdf : manuale utente
    --> Documento di analisi dei requisiti.pdf : documento di analisi dei requisiti

++ REQUISITI ++

L'applicazione richiede Java JDK 17, 18 o 19.
L'applicazione richiede l'installazione di pgadmin4.
NOTA: l'applicazione è stata sviluppata con Java JDK 18 e testata su macOS e Windows 11.

++ AVVIARE L'APPLICAZIONE ++

Se già presente un database EmotionalSongs su pgadmin eliminarlo.

Tramite linea di comando(prompt dei comandi) digitare:

cd (e in seguito impostare la directory su Users\...\Cermisoni_748739\bin e premere invio)

In seguito digitare:

java -jar (premere una volta lo spazio e in seguito trascinare il file .jar sul prompt e premere invio)

In seguito effettuare l'accesso immettendo username e password relative a postgres.
